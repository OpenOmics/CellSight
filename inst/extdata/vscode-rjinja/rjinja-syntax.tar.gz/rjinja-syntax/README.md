# R + jinjar (`.R.jinja`) syntax

Syntax highlighting for [jinjar](https://cran.r-project.org/package=jinjar) R
templates that use **custom delimiters** — as used by the ShinyCell code
generators. It colors the Jinja tags while embedding the real R grammar
(`source.r`) underneath, so the surrounding R code highlights normally.

Delimiters recognized:

| Construct | Syntax        |
|-----------|---------------|
| Variable  | `<< expr >>`  |
| Block     | `{% … %}`     |
| Comment   | `{# … #}`     |

## Requirements

The embedded R highlighting relies on a `source.r` grammar being present.
Install an R extension that provides it, e.g.
**REditorSupport R** (`reditorsupport.r-syntax` or `reditorsupport.r`).

## Install

From a terminal:

```sh
code --install-extension rjinja-syntax-0.0.2.vsix
```

or in VS Code: Extensions view → `…` menu → **Install from VSIX…** → pick the
`.vsix` file, then reload the window.

## File association

VS Code's extension matcher is unreliable for the compound extension
`.R.jinja`. Add this to your **workspace** `.vscode/settings.json` so the files
bind deterministically:

```json
{
  "files.associations": {
    "*.R.jinja": "rjinja",
    "*.r.jinja": "rjinja"
  }
}
```

## Notes

- This is a TextMate grammar (coloring only). It does not provide R
  IntelliSense or diagnostics inside templates — the R language server does not
  parse `.R.jinja` files.
- Coloring is theme-dependent; the grammar uses standard TextMate scopes
  (`keyword.control`, `comment.block`, `string`, …).

## Building the VSIX

```sh
docker run --rm -v "$PWD":/ext -w /ext \
  node:20-alpine sh -c "npm i -g @vscode/vsce && vsce package --allow-missing-repository"
```
